<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel = "stylesheet" href = "style.css">
    <title>Document</title>
</head>
<body>
<?php 
    require('connect.php');

    if(isset($_POST["username"]) && isset($_POST["email"]) && isset($_POST["password"])){
        $username = $_POST["username"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        print($username . ", " . $email . ", " . $password);

        $query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
        $result = mysqli_query($connection, $query);

        if($result){
            $msg = "Регистрация прошла успешно!";
        } else {
            $fmsg = "Ошибка регистрации";
        }
    }
    ?>
    <div class  ="container">
        <form class="form-signin" method="post">
            <h2>Registration</h2>
            <?php if(isset($msg)){ ?><div class = "alert alert-success" role = "alert"> <?php echo $msg; ?></div><?php } ?>
            <?php if(isset($fmsg)){ ?><div class = "alert alert-danger" role = "alert"> <?php echo $fmsg; ?></div><?php } ?>
            <input type = "text" name = "username" class="form-control" placeholder="Username" required>
            <input type = "email" name = "email" class="form-control" placeholder="Email"" required>
            <input type = "password" name = "password" class="form-control" placeholder="Password" required>
            <button class="btn btn-log btn-primary btn-block" type="submit">Register</button>
        </form>
    <div>
</body>
</html>