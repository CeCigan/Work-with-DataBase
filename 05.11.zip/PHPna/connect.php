<?php 
    $connection = mysqli_connect("localhost", "root", "A107wH21cRh91");
    $dateBase = mysqli_select_db($connection, "practice");

    if(isset($dateBase)){print("da");} else{print("Net");}
?>